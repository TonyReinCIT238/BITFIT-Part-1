package com.example.bitfit

data class FoodItem(val foodName: String, val calories: Int, val sleepHours: Int, val feeling: Float)

