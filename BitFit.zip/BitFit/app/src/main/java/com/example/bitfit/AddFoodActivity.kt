package com.example.bitfit

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class AddFoodActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_food)

        val foodNameEditText: EditText = findViewById(R.id.foodNameEditText)
        val caloriesEditText: EditText = findViewById(R.id.caloriesEditText)
        val saveButton: Button = findViewById(R.id.saveButton)

        saveButton.setOnClickListener {
            val foodName = foodNameEditText.text.toString()
            val calories = caloriesEditText.text.toString()

            if (foodName.isNotEmpty() && calories.isNotEmpty()) {
                val resultIntent = Intent()
                resultIntent.putExtra("foodName", foodName)
                resultIntent.putExtra("calories", calories)
                setResult(Activity.RESULT_OK, resultIntent)
                finish()
            } else {
            }
        }
    }
}
