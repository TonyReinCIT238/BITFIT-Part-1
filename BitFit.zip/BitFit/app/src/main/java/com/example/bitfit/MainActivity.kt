package com.example.bitfit

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.widget.RatingBar
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class MainActivity : AppCompatActivity() {

    private val foodList = mutableListOf<FoodItem>()
    private lateinit var adapter: FoodAdapter
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var gson: Gson

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sharedPreferences = getSharedPreferences("bitfit_prefs", Context.MODE_PRIVATE)
        gson = Gson()

        val sleepHoursSeekBar: SeekBar = findViewById(R.id.sleepHoursSeekBar)
        val feelingRatingBar: RatingBar = findViewById(R.id.feelingRatingBar)
        val sleepHoursProgressTextView: TextView = findViewById(R.id.sleepHoursProgressTextView)

        sleepHoursSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val selectedSleepHours = progress
                sleepHoursProgressTextView.text = "$selectedSleepHours hours"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })

        feelingRatingBar.setOnRatingBarChangeListener { ratingBar, rating, fromUser ->
        }

        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        adapter = FoodAdapter(foodList)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        val foodNameEditText: EditText = findViewById(R.id.foodNameEditText)
        val caloriesEditText: EditText = findViewById(R.id.caloriesEditText)
        val addButton: Button = findViewById(R.id.addFoodButton)

        val userDataJson = sharedPreferences.getString("user_data", null)
        if (userDataJson != null) {
            val typeToken = object : TypeToken<List<FoodItem>>() {}.type
            val savedFoodList = gson.fromJson<List<FoodItem>>(userDataJson, typeToken)
            foodList.addAll(savedFoodList)
            adapter.notifyDataSetChanged()
        }

        addButton.setOnClickListener {
            val foodName = foodNameEditText.text.toString()
            val calories = caloriesEditText.text.toString().toIntOrNull()
            val sleepHours = sleepHoursSeekBar.progress
            val feeling = feelingRatingBar.rating

            if (!foodName.isEmpty() && calories != null) {
                val foodItem = FoodItem(foodName, calories, sleepHours, feeling)
                foodList.add(foodItem)
                adapter.notifyDataSetChanged()
                foodNameEditText.text.clear()
                caloriesEditText.text.clear()

                val userDataJson = gson.toJson(foodList)
                sharedPreferences.edit().putString("user_data", userDataJson).apply()

                sleepHoursSeekBar.progress = 0
                feelingRatingBar.rating = 0.0f
            } else {
                Toast.makeText(this, "Please enter valid data", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
